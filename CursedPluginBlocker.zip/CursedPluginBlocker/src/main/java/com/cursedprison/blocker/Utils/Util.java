package com.cursedprison.blocker.Utils;


import net.md_5.bungee.api.ChatColor;

public class Util {

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

}
